﻿import urllib.request
from PIL import Image
import sys

# Download the image
url = "https://res.cloudinary.com/dlttxqrod/image/upload/v1785133185/035A0540_j4rf38.jpg"
filename = "temp_matchbox.jpg"
urllib.request.urlretrieve(url, filename)

# Open image
img = Image.open(filename)
img = img.convert("RGB")
width, height = img.size

# The background is beige. We will look for pixels that are NOT beige.
# Beige is roughly R>200, G>180, B>150. Let's look for dark pixels or very red pixels (the flame/text/black box).
# Let's find the bounding box of anything that is significantly darker than the beige background.
# Sample the top-left corner to get the background color
bg_r, bg_g, bg_b = img.getpixel((0, 0))

left = width
right = 0
top = height
bottom = 0

for y in range(height):
    for x in range(width):
        r, g, b = img.getpixel((x, y))
        # Distance from background color
        dist = abs(r - bg_r) + abs(g - bg_g) + abs(b - bg_b)
        
        # If difference is significant, it's part of the matchbox
        if dist > 60:
            if x < left: left = x
            if x > right: right = x
            if y < top: top = y
            if y > bottom: bottom = y

# Calculate UV mapping
# U goes from 0 to 1 (left to right)
# V goes from 0 to 1 (bottom to top)

u_min = left / width
u_max = right / width
# Note: Image Y=0 is top, Y=height is bottom. Three.js V=0 is bottom, V=1 is top.
v_min = (height - bottom) / height
v_max = (height - top) / height

uv_width = u_max - u_min
uv_height = v_max - v_min

offset_u = u_min
offset_v = v_min

print(f"Image Size: {width}x{height}")
print(f"Bounding Box: Left={left}, Right={right}, Top={top}, Bottom={bottom}")
print(f"UV Width (Repeat X): {uv_width}")
print(f"UV Height (Repeat Y): {uv_height}")
print(f"Offset X: {offset_u}")
print(f"Offset Y: {offset_v}")
